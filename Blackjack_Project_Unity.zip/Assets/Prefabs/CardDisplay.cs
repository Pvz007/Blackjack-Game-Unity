using UnityEngine;

public class CardDisplay : MonoBehaviour
{
    public SpriteRenderer spriteRenderer;

    void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void SetCard(Sprite sprite)
    {
        spriteRenderer.sprite = sprite;
    }
}