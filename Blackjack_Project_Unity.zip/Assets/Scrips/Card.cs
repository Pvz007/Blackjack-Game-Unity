using System;

[Serializable]
public class Card
{
    public string suit;
    public string rank;
    public int value;
    public string spriteName;

    public Card(string suit,string rank,int value)
{
    this.suit=suit;
    this.rank=rank;
    this.value=value;

    string suitName=suit.ToLower();

    if(rank=="A")
        spriteName="card_"+suitName+"_A";
    else if(rank=="J")
        spriteName="card_"+suitName+"_J";
    else if(rank=="Q")
        spriteName="card_"+suitName+"_Q";
    else if(rank=="K")
        spriteName="card_"+suitName+"_K";
    else
    {
        int number=int.Parse(rank);
        spriteName="card_"+suitName+"_"+number.ToString("00");
    }
}
}