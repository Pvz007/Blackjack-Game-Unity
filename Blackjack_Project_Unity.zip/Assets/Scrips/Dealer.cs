using UnityEngine;

public class Dealer : Player
{
    public void PlayTurn(Deck deck)
    {
        while(GetScore()<17)
        {
            AddCard(deck.DrawCard());
        }
    }
}