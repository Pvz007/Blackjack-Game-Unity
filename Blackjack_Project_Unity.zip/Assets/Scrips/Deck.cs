using System.Collections.Generic;
using UnityEngine;

public class Deck : MonoBehaviour
{
    public List<Card> cards=new List<Card>();

    public void CreateDeck()
    {
        cards.Clear();

        string[] suits={"Hearts","Diamonds","Clubs","Spades"};
        string[] ranks={"A","2","3","4","5","6","7","8","9","10","J","Q","K"};

        foreach(string suit in suits)
        {
            for(int i=0;i<13;i++)
            {
                int value=i+1;

                if(value>10)
                    value=10;

                cards.Add(new Card(suit,ranks[i],value));
            }
        }
    }

    public void Shuffle()
    {
        for(int i=0;i<cards.Count;i++)
        {
            int random=Random.Range(i,cards.Count);

            Card temp=cards[i];
            cards[i]=cards[random];
            cards[random]=temp;
        }
    }

    public Card DrawCard()
    {
        Card card=cards[0];
        cards.RemoveAt(0);
        return card;
    }
}