using UnityEngine;
using TMPro;
using System.Collections;

public class GameManager : MonoBehaviour
{
    public GameObject cardPrefab;
    public Transform playerCardArea;
    public Transform dealerCardArea;

    public Deck deck;
    public Player player;
    public Dealer dealer;

    public TMP_Text playerScore;
    public TMP_Text dealerScore;
    public TMP_Text message;

    public TMP_Text roundText;
    public TMP_Text chipsText;
    public TMP_Text dealerChipsText;
    public TMP_Text deckText;
    public TMP_Text statsText;

    bool gameOver=false;
    bool dealerHidden=true;
    bool dealerThinking=false;

    int round=1;

    int wins=0;
    int losses=0;
    int pushes=0;
    int blackjacks=0;

    int chips=1000;
    int dealerChips=1000;
    int bet=100;

    void Start()
    {
        StartGame();
    }

    public void StartGame()
    {
        gameOver=false;
        dealerHidden=true;
        dealerThinking=false;

        roundText.text="ROUND "+round;

        if(deck.cards.Count<15)
        {
            message.text="Shuffling...";
            deck.CreateDeck();
            deck.Shuffle();
        }

        player.ClearHand();
        dealer.ClearHand();

        ClearCards();

        player.AddCard(deck.DrawCard());
        dealer.AddCard(deck.DrawCard());

        player.AddCard(deck.DrawCard());
        dealer.AddCard(deck.DrawCard());

        StartCoroutine(DealOpeningCards());

        int p=player.GetScore();
        int d=dealer.GetScore();

        if(p==21 && d==21)
        {
            message.text="Push!";
            pushes++;
            gameOver=true;
            Invoke(nameof(NextRound),2f);
        }
        else if(p==21)
        {
            dealerHidden=false;
            blackjacks++;
            wins++;
            chips+=bet;
            dealerChips-=bet;

            DisplayCards();
            UpdateUI();

            message.text="BLACKJACK!";
            gameOver=true;

            Invoke(nameof(NextRound),2f);
        }
        else if(d==21)
        {
            dealerHidden=false;
            losses++;
            chips-=bet;
            dealerChips+=bet;

            DisplayCards();
            UpdateUI();

            message.text="Dealer Blackjack!";
            gameOver=true;

            Invoke(nameof(NextRound),2f);
        }
        if(chips<=0)
{
    message.text="GAME OVER";
    gameOver=true;
}
if(dealerChips<=0)
{
    message.text="YOU BEAT THE CASINO!";
    gameOver=true;
}
        else
        {
            message.text="Your Turn";
        }
    }

    void UpdateUI()
    {
        playerScore.text="PLAYER\n"+player.GetScore();

        if(dealerHidden)
            dealerScore.text="DEALER\n? + "+dealer.hand[1].rank;
        else
            dealerScore.text="DEALER\n"+dealer.GetScore();

        chipsText.text="Player's Chips:"+chips;
        dealerChipsText.text="Dealer's Chips"+dealerChips;
        deckText.text="Cards Left\n"+deck.cards.Count;

        statsText.text=
        "PLAYER : "+wins+
        "\nDEALER : "+losses+
        "\nPUSHES : "+pushes+
        "\nBLACKJACKS : "+blackjacks;
    }
public void Hit()
{
    if(gameOver || dealerThinking)
        return;

    player.AddCard(deck.DrawCard());

    DisplayCards();
    UpdateUI();

    if(player.GetScore()>21)
    {
        dealerHidden=false;

        DisplayCards();
        UpdateUI();

        message.text="BUST!";

        losses++;
        chips-=bet;

        gameOver=true;

        Invoke(nameof(NextRound),2f);
    }
}

public void Stand()
{
    if(gameOver || dealerThinking)
        return;

    StartCoroutine(DealerTurn());
}

IEnumerator DealerTurn()
{
    dealerThinking=true;

    dealerHidden=false;

    DisplayCards();
    UpdateUI();

    message.text="Dealer is thinking...";

    yield return new WaitForSeconds(3f);

    while(dealer.GetScore()<17)
{

    dealer.AddCard(deck.DrawCard());

    DisplayCards();
    UpdateUI();

    yield return new WaitForSeconds(0.8f);
}

    int p=player.GetScore();
    int d=dealer.GetScore();

    if(d>21)
    {
        wins++;
        chips+=bet;
        dealerChips-=bet;
        message.text="YOU WIN!";
    }
    else if(p>d)
    {
        wins++;
        chips+=bet;
        dealerChips-=bet;
        message.text="YOU WIN!";
    }
    else if(d>p)
    {
        losses++;
        chips-=bet;

        message.text="DEALER WINS!";
    }
    else
    {
        pushes++;

        message.text="PUSH!";
    }

    dealerThinking=false;
    gameOver=true;

    UpdateUI();

    yield return new WaitForSeconds(2f);

    NextRound();
}
void DisplayCards()
{
    ClearCards();

    Sprite[] sprites=Resources.LoadAll<Sprite>("Cards");

    // PLAYER
    for(int i=0;i<player.hand.Count;i++)
    {
        GameObject obj=Instantiate(cardPrefab,playerCardArea);

        obj.transform.localPosition=new Vector3(i*5f,0f,0f);
        obj.transform.localRotation=Quaternion.identity;
        obj.transform.localScale=new Vector3(0.75f,0.75f,1f);

        SpriteRenderer sr=obj.GetComponent<SpriteRenderer>();

        foreach(Sprite s in sprites)
        {
            if(s.name==player.hand[i].spriteName+"_0")
            {
                sr.sprite=s;
                break;
            }
        }
    }

    // DEALER
    for(int i=0;i<dealer.hand.Count;i++)
    {
        GameObject obj=Instantiate(cardPrefab,dealerCardArea);

        obj.transform.localPosition=new Vector3(i*5f,0f,0f);
        obj.transform.localRotation=Quaternion.identity;
        obj.transform.localScale=new Vector3(0.75f,0.75f,1f);

        SpriteRenderer sr=obj.GetComponent<SpriteRenderer>();

        if(i==0 && dealerHidden)
        {
            foreach(Sprite s in sprites)
            {
                if(s.name=="card_back_0")
                {
                    sr.sprite=s;
                    break;
                }
            }
        }
        else
        {
            foreach(Sprite s in sprites)
            {
                if(s.name==dealer.hand[i].spriteName+"_0")
                {
                    sr.sprite=s;
                    break;
                }
            }
        }
    }
}
IEnumerator DealOpeningCards()
{
    DisplayCards();
    UpdateUI();

    yield return null;
}

void ClearCards()
{
    foreach(Transform child in playerCardArea)
        Destroy(child.gameObject);

    foreach(Transform child in dealerCardArea)
        Destroy(child.gameObject);
}

void NextRound()
{
    round++;
    StartGame();
}
}