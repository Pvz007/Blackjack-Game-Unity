using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public List<Card> hand=new List<Card>();

    public void AddCard(Card card)
    {
        hand.Add(card);
    }

    public void ClearHand()
    {
        hand.Clear();
    }

    public int GetScore()
    {
        int score=0;
        int aces=0;

        foreach(Card card in hand)
        {
            if(card.rank=="A")
            {
                score+=11;
                aces++;
            }
            else
            {
                score+=card.value;
            }
        }

        while(score>21 && aces>0)
        {
            score-=10;
            aces--;
        }

        return score;
    }
}